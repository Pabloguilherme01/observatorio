# Estrutura recomendada do projeto (Vite + React + TypeScript + Tailwind)

> **Rodada 1:** somente parte dos arquivos abaixo foi implementada.\
> Componentes futuros estão listados para orientar a modularização completa.

```text
observatorio_eleitoral/
├── docs/
│   └── estrutura-do-projeto.md
├── public/
│   ├── favicon.svg
│   └── imagens/
│       ├── og-observatorio.png
│       └── story-template.png
├── src/
│   ├── app/
│   │   ├── App.tsx
│   │   ├── Router.tsx
│   │   └── providers/
│   │       ├── ThemeProvider.tsx
│   │       └── AccessibilityProvider.tsx
│   ├── components/
│   │   ├── Header.tsx
│   │   ├── HeroCountdown.tsx
│   │   ├── DashboardMetrics.tsx
│   │   ├── SanitationHealthSection.tsx
│   │   ├── PoliticalRadar.tsx
│   │   ├── TransportCalculator.tsx
│   │   ├── DataExportActions.tsx
│   │   ├── cards/
│   │   │   ├── MetricCard.tsx
│   │   │   └── SourceBadge.tsx
│   │   ├── charts/
│   │   │   ├── LineChartSvg.tsx
│   │   │   ├── BarChartSvg.tsx
│   │   │   └── RadarChartSvg.tsx
│   │   └── ui/
│   │       ├── Button.tsx
│   │       ├── Input.tsx
│   │       └── SectionTitle.tsx
│   ├── data/
│   │   ├── observatorioData.ts
│   │   └── fontes.ts
│   ├── hooks/
│   │   ├── useCountdown.ts
│   │   ├── useKeyboardSearch.ts
│   │   └── useTheme.ts
│   ├── lib/
│   │   ├── formatters/
│   │   │   ├── currency.ts
│   │   │   ├── number.ts
│   │   │   └── percent.ts
│   │   ├── calculations/
│   │   │   ├── transport.ts
│   │   │   ├── electorate.ts
│   │   │   └── sanitation.ts
│   │   ├── export/
│   │   │   ├── csv.ts
│   │   │   ├── canvas.ts
│   │   │   └── clipboard.ts
│   │   └── constants.ts
│   ├── styles/
│   │   ├── globals.css
│   │   └── tokens.css
│   ├── types/
│   │   ├── observatorio.ts
│   │   └── common.ts
│   ├── tests/
│   │   ├── unit/
│   │   │   ├── calculations.transport.test.ts
│   │   │   └── export.csv.test.ts
│   │   └── accessibility/
│   │       └── wcag-aa.test.tsx
│   ├── main.tsx
│   └── vite-env.d.ts
├── .eslintrc.cjs
├── .prettierrc
├── index.html
├── package.json
├── postcss.config.cjs
├── tailwind.config.ts
├── tsconfig.json
└── vite.config.ts
```

## Arquivos já implementados na Rodada 1

* `types/observatorio.ts`

* `data/observatorioData.ts`

* `components/TransportCalculator.tsx`

* `components/DataExportActions.tsx`

* `docs/estrutura-do-projeto.md`