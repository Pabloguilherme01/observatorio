import { AlertTriangle, Droplets, HeartPulse, TrendingUp } from "lucide-react";
import { useMemo, useState } from "react";
import { observatorioData } from "../data/observatorioData";
import type { ObservatorioData } from "../types/observatorio";
import { buildSmoothPath } from "./DashboardMetrics";

/** Gera pontos intermediários de uma curva de crescimento acelerado. */
export const buildGrowthCurvePoints = (
  start: { x: number; y: number },
  end: { x: number; y: number },
  segments = 5,
): Array<{ x: number; y: number }> => {
  const points: Array<{ x: number; y: number }> = [];
  for (let i = 0; i < segments; i += 1) {
    const t = i / (segments - 1);
    const eased = t ** 1.8;
    points.push({
      x: start.x + (end.x - start.x) * t,
      y: start.y + (end.y - start.y) * eased,
    });
  }
  return points;
};

export interface SanitationHealthSectionProps {
  /** Dados do observatório (padrão: base canônica). */
  data?: ObservatorioData;
}

/**
 * Seção integrada de Saneamento (curva 2,9% → 84,8%, barras 360° e alerta de
 * 427 internações) e Saúde HEALGO (pressão de demanda 1.219 atend/leito e
 * necessidade de expansão para 298 leitos).
 */
export function SanitationHealthSection({ data = observatorioData }: SanitationHealthSectionProps) {
  const { saneamento, saude } = data;
  const [leitosSlider, setLeitosSlider] = useState<number>(saude.healgoLeitos);

  const crescimentoEsgotoPct = ((saneamento.esgoto2024Pct - saneamento.esgoto2017Pct) / saneamento.esgoto2017Pct) * 100;
  const atendimentosPorLeito = saude.healgoAtendimentosAno / leitosSlider;
  const atendimentosPorLeitoAtual = saude.healgoAtendimentosAno / saude.healgoLeitos;
  const atendimentosPorLeitoProjetado = saude.healgoAtendimentosAno / saude.healgoLeitosProjetado;
  const reducaoPressaoPct =
    (1 - atendimentosPorLeitoProjetado / atendimentosPorLeitoAtual) * 100;

  const curvaSaneamento = useMemo(
    () =>
      buildGrowthCurvePoints(
        { x: 20, y: 100 },
        { x: 260, y: 18 },
      ),
    [],
  );

  const barras360 = [
    { chave: `Água ${saneamento.aguaPct}%`, valor: saneamento.aguaPct, barClassName: "bg-sky-500" },
    { chave: `Esgoto ${saneamento.esgoto2024Pct}%`, valor: saneamento.esgoto2024Pct, barClassName: "bg-emerald-500" },
    { chave: `Tratado/água ${saneamento.esgotoTratadoSobreAguaPct}%`, valor: saneamento.esgotoTratadoSobreAguaPct, barClassName: "bg-amber-500" },
    { chave: "Vol 100%", valor: 100, barClassName: "bg-violet-500" },
    { chave: `Perdas ${saneamento.perdasPct ?? 0}%`, valor: saneamento.perdasPct ?? 0, barClassName: "bg-rose-500" },
    { chave: `Hidrometração ${saneamento.hidrometracaoPct ?? 0}%`, valor: saneamento.hidrometracaoPct ?? 0, barClassName: "bg-sky-500" },
  ];

  const healgoStats = [
    { label: "Investimento", value: `R$ ${saude.healgoInvestimentoMilhoes}M` },
    { label: "Atendimentos/ano", value: saude.healgoAtendimentosAno.toLocaleString("pt-BR") },
    { label: "População alcançada", value: saude.healgoPopulacaoAlcancada.toLocaleString("pt-BR") },
    { label: "Área construída", value: `${saude.healgoAreaConstruidaM2.toLocaleString("pt-BR")} m²` },
    { label: "Celetistas", value: String(saude.healgoCeletistas ?? 0) },
  ];

  return (
    <section aria-labelledby="titulo-saneamento-saude" className="scroll-mt-20 px-4 py-10">
      <div className="mx-auto max-w-7xl">
        <h2
          id="titulo-saneamento-saude"
          className="text-2xl font-extrabold text-slate-900 dark:text-slate-50"
        >
          Saneamento + Saúde HEALGO
        </h2>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Diagnóstico integrado: infraestrutura sanitária e pressão assistencial hospitalar.
        </p>

        {/* Saneamento */}
        <div className="mt-6">
          <h3 className="flex items-center gap-2 text-lg font-extrabold text-slate-800 dark:text-slate-200">
            <Droplets size={18} className="text-sky-500" aria-hidden="true" />
            Saneamento Expandido • {saneamento.semEsgotoAbs.toLocaleString("pt-BR")} sem coleta{" "}
            {saneamento.semEsgotoPct}% • {saneamento.semAguaAbs?.toLocaleString("pt-BR")} sem água{" "}
            {saneamento.semAguaPct}% • {saneamento.perdasPct}% perdas
          </h3>

          <div className="mt-4 grid gap-4 lg:grid-cols-3">
            <article className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900">
              <h4 className="flex items-center gap-2 text-xs font-extrabold text-slate-800 dark:text-slate-200">
                <TrendingUp size={16} className="text-emerald-500" aria-hidden="true" />
                Curva {saneamento.esgoto2017Pct}%→{saneamento.esgoto2024Pct}% = +{crescimentoEsgotoPct.toFixed(0)}%
              </h4>
              <svg
                viewBox="0 0 300 120"
                className="mt-3 h-auto w-full"
                role="img"
                aria-label="Curva de crescimento do esgotamento sanitário de 2,9% em 2017 para 84,8% em 2024"
              >
                <path
                  d={buildSmoothPath(curvaSaneamento)}
                  fill="none"
                  className="stroke-emerald-500"
                  strokeWidth="3"
                  strokeLinecap="round"
                />
                <circle cx="20" cy="100" r="5" className="fill-rose-500" />
                <circle cx="260" cy="18" r="5" className="fill-emerald-500" />
                <text x="20" y="115" fontSize="9" className="fill-slate-500 dark:fill-slate-400">
                  {saneamento.esgoto2017Pct}% 2017
                </text>
                <text x="200" y="12" fontSize="10" fontWeight="800" className="fill-emerald-600 dark:fill-emerald-400">
                  {saneamento.esgoto2024Pct}% 2024
                </text>
              </svg>
              <p className="mt-2 text-[11px] text-slate-500 dark:text-slate-400">
                Crescimento {crescimentoEsgotoPct.toFixed(0)}% • (84.8-2.9)/2.9*100 • comparação GO{" "}
                {saneamento.mediaGoiasPct ?? 0}% país {saneamento.mediaBrasilPct ?? 0}%
              </p>
            </article>

            <article className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900">
              <h4 className="text-xs font-extrabold text-slate-800 dark:text-slate-200">
                Saneamento 360° • cobertura≠coleta≠tratamento
              </h4>
              <div className="mt-3 flex flex-col gap-2.5">
                {barras360.map((barra) => (
                  <div key={barra.chave} className="flex items-center gap-2">
                    <span className="w-[130px] shrink-0 text-[10px] text-slate-600 dark:text-slate-300">
                      {barra.chave}
                    </span>
                    <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-200 dark:bg-slate-700">
                      <div
                        className={`h-full rounded-full ${barra.barClassName}`}
                        style={{ width: `${barra.valor}%` }}
                      />
                    </div>
                    <span className="w-9 shrink-0 text-right text-[10px] font-extrabold text-slate-700 dark:text-slate-200">
                      {barra.valor}%
                    </span>
                  </div>
                ))}
              </div>
              <p className="mt-3 text-[10px] text-slate-500 dark:text-slate-400">
                {saneamento.consumoLitrosHabDia} L/hab/dia • R${saneamento.precoM3}/m³ •{" "}
                {saneamento.residuosPct}% resíduos • SINISA base 2025
              </p>
            </article>

            <article className="rounded-2xl border border-rose-200 bg-rose-50/60 p-5 shadow-sm dark:border-rose-900 dark:bg-rose-950/30">
              <h4 className="flex items-center gap-2 text-xs font-extrabold text-rose-700 dark:text-rose-300">
                <AlertTriangle size={16} aria-hidden="true" />
                {saneamento.internacoesAgua} internações • {saneamento.obitosAgua} óbitos • R$30 mi • R$
                {saneamento.investimentoPerCapita} p.c.
              </h4>
              <p className="mt-2 text-3xl font-black text-rose-600 dark:text-rose-400">
                {saneamento.internacoesAgua}
              </p>
              <p className="mt-1 text-[11px] text-rose-700/80 dark:text-rose-300/80">
                Indicador 2024 • falta saneamento vetor direto doenças • gargalo crítico
              </p>
              <div className="mt-3 rounded-xl border border-rose-200 bg-white/70 p-3 text-[11px] leading-relaxed text-rose-800 dark:border-rose-800 dark:bg-slate-900/60 dark:text-rose-200">
                Invest R$ {saneamento.investimentoSaneamento.toLocaleString("pt-BR")} • Per capita R$
                {saneamento.investimentoPerCapita} • Sem coleta {saneamento.semEsgotoAbs.toLocaleString("pt-BR")}{" "}
                {saneamento.semEsgotoPct}% • Sem água {saneamento.semAguaAbs?.toLocaleString("pt-BR")}{" "}
                {saneamento.semAguaPct}% • {saneamento.obitosAgua} óbitos hídricos
              </div>
            </article>
          </div>
        </div>

        {/* Saúde HEALGO */}
        <div className="mt-10">
          <h3 className="flex items-center gap-2 text-lg font-extrabold text-slate-800 dark:text-slate-200">
            <HeartPulse size={18} className="text-sky-500" aria-hidden="true" />
            Saúde HEALGO Detalhado • R${saude.healgoInvestimentoMilhoes}M •{" "}
            {saude.healgoAtendimentosAno.toLocaleString("pt-BR")} atend •{" "}
            {saude.healgoPopulacaoAlcancada.toLocaleString("pt-BR")} pop •{" "}
            {saude.healgoAreaConstruidaM2.toLocaleString("pt-BR")} m² • {saude.healgoCeletistas ?? 0} celetistas
          </h3>

          <div className="mt-4 grid gap-4 lg:grid-cols-2">
            <article className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900">
              <p className="text-[11px] font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                Pressão de demanda • expansão {saude.healgoLeitos}→{saude.healgoLeitosProjetado} leitos
              </p>
              <p className="mt-2 text-3xl font-black text-sky-600 dark:text-sky-400">
                {atendimentosPorLeitoAtual.toFixed(0)} atend/leito/ano
              </p>
              <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
                {saude.healgoAtendimentosAno.toLocaleString("pt-BR")}/{leitosSlider} ={" "}
                {atendimentosPorLeito.toFixed(0)} • projeção {saude.healgoLeitosProjetado} ={" "}
                {atendimentosPorLeitoProjetado.toFixed(0)} • redução {reducaoPressaoPct.toFixed(0)}%
              </p>
              <label
                htmlFor="slider-leitos-healgo"
                className="mt-3 block text-[11px] font-semibold text-slate-600 dark:text-slate-300"
              >
                Simular leitos: {leitosSlider}
              </label>
              <input
                id="slider-leitos-healgo"
                type="range"
                min={saude.healgoLeitos}
                max={saude.healgoLeitosProjetado}
                value={leitosSlider}
                onChange={(event) => setLeitosSlider(Number(event.target.value))}
                className="mt-1 w-full accent-sky-600"
                aria-label="Simular quantidade de leitos do HEALGO"
              />
              <p className="mt-3 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
                Composição: {saude.healgoUti} UTI + {saude.healgoEnfermaria} Enf + {saude.healgoUcin} UCIN +{" "}
                {saude.healgoOutros ?? 0} outros = {saude.healgoLeitos} • ampliação{" "}
                {saude.healgoLeitosProjetado} necessidade estratégica
              </p>
            </article>

            <article className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900">
              <p className="text-[11px] font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                HEALGO em números
              </p>
              <dl className="mt-3 grid grid-cols-2 gap-3">
                {healgoStats.map((stat) => (
                  <div
                    key={stat.label}
                    className="rounded-xl border border-slate-200 bg-slate-50 p-3 dark:border-slate-700 dark:bg-slate-800/60"
                  >
                    <dt className="text-[10px] font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                      {stat.label}
                    </dt>
                    <dd className="mt-1 text-base font-black text-slate-900 dark:text-slate-100">
                      {stat.value}
                    </dd>
                  </div>
                ))}
              </dl>
              <p className="mt-3 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
                {saude.healgoLeitos} leitos atuais para {saude.healgoAtendimentosAno.toLocaleString("pt-BR")}{" "}
                atendimentos/ano geram {atendimentosPorLeitoAtual.toFixed(0)} atend/leito — a expansão para{" "}
                {saude.healgoLeitosProjetado} leitos reduz a pressão para{" "}
                {atendimentosPorLeitoProjetado.toFixed(0)} atend/leito/ano (redução de{" "}
                {reducaoPressaoPct.toFixed(0)}%).
              </p>
            </article>
          </div>
        </div>
      </div>
    </section>
  );
}

export default SanitationHealthSection;
