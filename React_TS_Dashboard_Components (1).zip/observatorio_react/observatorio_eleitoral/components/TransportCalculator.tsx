import { useMemo, useState } from "react";

/** Parâmetros de entrada para cálculo de custo de transporte. */
export interface TransportCalculationInput {
  tarifa: number;
  diasUteis: number;
  pessoas: number;
  salarioMinimo: number;
}

/** Resultado detalhado dos cálculos de mobilidade. */
export interface TransportCalculationResult {
  custoMensalIndividual: number;
  custoMensalFamiliar: number;
  custoAnualIndividual: number;
  custoAnualFamiliar: number;
  percentualSmIndividual: number;
  percentualSmFamiliar: number;
}

/** Arredonda valores monetários com duas casas decimais. */
export const roundCurrency = (value: number): number =>
  Math.round((value + Number.EPSILON) * 100) / 100;

/**
 * Calcula os custos de transporte considerando ida e volta diária.
 */
export const calculateTransportCosts = (
  input: TransportCalculationInput,
): TransportCalculationResult => {
  const tarifa = Number.isFinite(input.tarifa) ? Math.max(0, input.tarifa) : 0;
  const diasUteis = Number.isFinite(input.diasUteis)
    ? Math.max(0, Math.floor(input.diasUteis))
    : 0;
  const pessoas = Number.isFinite(input.pessoas)
    ? Math.max(1, Math.floor(input.pessoas))
    : 1;
  const salarioMinimo = Number.isFinite(input.salarioMinimo)
    ? Math.max(0.01, input.salarioMinimo)
    : 0.01;

  const custoMensalIndividual = tarifa * 2 * diasUteis;
  const custoMensalFamiliar = custoMensalIndividual * pessoas;
  const custoAnualIndividual = custoMensalIndividual * 12;
  const custoAnualFamiliar = custoMensalFamiliar * 12;

  return {
    custoMensalIndividual: roundCurrency(custoMensalIndividual),
    custoMensalFamiliar: roundCurrency(custoMensalFamiliar),
    custoAnualIndividual: roundCurrency(custoAnualIndividual),
    custoAnualFamiliar: roundCurrency(custoAnualFamiliar),
    percentualSmIndividual: roundCurrency((custoMensalIndividual / salarioMinimo) * 100),
    percentualSmFamiliar: roundCurrency((custoMensalFamiliar / salarioMinimo) * 100),
  };
};

export interface TransportCalculatorProps {
  /** Tarifa padrão inicial. */
  defaultTarifa?: number;
  /** Dias úteis padrão no mês. */
  defaultDiasUteis?: number;
  /** Quantidade padrão de pessoas. */
  defaultPessoas?: number;
  /** Salário mínimo usado para comparação de impacto. */
  salarioMinimo?: number;
}

const DEFAULT_TARIFA = 11.45;
const DEFAULT_DIAS_UTEIS = 22;
const DEFAULT_PESSOAS = 1;
const DEFAULT_SM = 1621;

const inputClassName =
  "mt-2 w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-slate-900 shadow-sm outline-none transition focus:border-blue-600 focus:ring-2 focus:ring-blue-200";

/**
 * Calculadora acessível de custo de transporte mensal/anual.
 */
export function TransportCalculator({
  defaultTarifa = DEFAULT_TARIFA,
  defaultDiasUteis = DEFAULT_DIAS_UTEIS,
  defaultPessoas = DEFAULT_PESSOAS,
  salarioMinimo = DEFAULT_SM,
}: TransportCalculatorProps) {
  const [tarifa, setTarifa] = useState<number>(defaultTarifa);
  const [diasUteis, setDiasUteis] = useState<number>(defaultDiasUteis);
  const [pessoas, setPessoas] = useState<number>(defaultPessoas);

  const resultado = useMemo(
    () => calculateTransportCosts({ tarifa, diasUteis, pessoas, salarioMinimo }),
    [tarifa, diasUteis, pessoas, salarioMinimo],
  );

  return (
    <section
      aria-labelledby="titulo-calculadora-transporte"
      className="rounded-2xl border border-slate-200 bg-slate-50 p-6 shadow-sm"
    >
      <header className="mb-4">
        <h3 id="titulo-calculadora-transporte" className="text-xl font-bold text-slate-900">
          Calculadora de Custo de Transporte
        </h3>
        <p className="mt-1 text-sm text-slate-600">
          Simule o impacto da tarifa no orçamento mensal e anual, comparando com o salário
          mínimo vigente.
        </p>
      </header>

      <form className="grid gap-4 md:grid-cols-3" aria-describedby="resumo-calculo-transporte">
        <div>
          <label htmlFor="tarifa" className="text-sm font-medium text-slate-800">
            Tarifa (R$)
          </label>
          <input
            id="tarifa"
            name="tarifa"
            type="number"
            step="0.01"
            min={0}
            value={tarifa}
            onChange={(event) => setTarifa(Number(event.target.value || 0))}
            className={inputClassName}
            aria-label="Valor da tarifa"
          />
        </div>

        <div>
          <label htmlFor="diasUteis" className="text-sm font-medium text-slate-800">
            Dias úteis por mês
          </label>
          <input
            id="diasUteis"
            name="diasUteis"
            type="number"
            step="1"
            min={0}
            value={diasUteis}
            onChange={(event) => setDiasUteis(Number(event.target.value || 0))}
            className={inputClassName}
            aria-label="Dias úteis por mês"
          />
        </div>

        <div>
          <label htmlFor="pessoas" className="text-sm font-medium text-slate-800">
            Número de pessoas
          </label>
          <input
            id="pessoas"
            name="pessoas"
            type="number"
            step="1"
            min={1}
            value={pessoas}
            onChange={(event) => setPessoas(Math.max(1, Number(event.target.value || 1)))}
            className={inputClassName}
            aria-label="Quantidade de pessoas"
          />
        </div>
      </form>

      <div
        id="resumo-calculo-transporte"
        className="mt-6 grid gap-3 md:grid-cols-2"
        role="status"
        aria-live="polite"
      >
        <article className="rounded-xl border border-slate-200 bg-white p-4">
          <h4 className="text-sm font-semibold text-slate-700">Custo individual</h4>
          <p className="mt-2 text-lg font-bold text-slate-900">
            Mensal: R$ {resultado.custoMensalIndividual.toFixed(2)}
          </p>
          <p className="text-sm text-slate-700">Anual: R$ {resultado.custoAnualIndividual.toFixed(2)}</p>
          <p className="mt-1 text-sm text-blue-700">
            {resultado.percentualSmIndividual.toFixed(2)}% do salário mínimo (R$ {salarioMinimo.toFixed(2)})
          </p>
        </article>

        <article className="rounded-xl border border-slate-200 bg-white p-4">
          <h4 className="text-sm font-semibold text-slate-700">Custo para {Math.max(1, pessoas)} pessoa(s)</h4>
          <p className="mt-2 text-lg font-bold text-slate-900">
            Mensal: R$ {resultado.custoMensalFamiliar.toFixed(2)}
          </p>
          <p className="text-sm text-slate-700">Anual: R$ {resultado.custoAnualFamiliar.toFixed(2)}</p>
          <p className="mt-1 text-sm text-blue-700">
            {resultado.percentualSmFamiliar.toFixed(2)}% do salário mínimo
          </p>
        </article>
      </div>
    </section>
  );
}

export default TransportCalculator;
