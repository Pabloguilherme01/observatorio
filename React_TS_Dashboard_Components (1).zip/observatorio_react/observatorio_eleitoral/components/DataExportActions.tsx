import { Copy, Download, Image as ImageIcon, Share2 } from "lucide-react";
import { useMemo, useState } from "react";

export interface CsvRow {
  [key: string]: string | number | null | undefined;
}

export interface ExportMetadata {
  titulo: string;
  versao: string;
  populacao: number;
  eleitorado: number;
  referencia: string;
}

export interface DataExportActionsProps {
  rows: CsvRow[];
  metadata: ExportMetadata;
}

/** Escapa valores para CSV seguro com separador de vírgula. */
export const escapeCsvValue = (value: unknown): string => {
  const normalized = String(value ?? "");
  const escaped = normalized.replaceAll('"', '""');
  return /[",\n]/.test(escaped) ? `"${escaped}"` : escaped;
};

/** Constrói conteúdo CSV incluindo BOM UTF-8. */
export const buildCsvWithBom = (rows: CsvRow[]): string => {
  if (!rows.length) return "\uFEFF";

  const headers = Object.keys(rows[0]);
  const lines = [headers.join(",")];

  for (const row of rows) {
    const line = headers.map((header) => escapeCsvValue(row[header])).join(",");
    lines.push(line);
  }

  return `\uFEFF${lines.join("\n")}`;
};

/** Faz download de um blob no navegador. */
export const downloadBlob = (content: BlobPart, fileName: string, mimeType: string): void => {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = fileName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
};

/**
 * Gera um card vertical (story) com os principais metadados em canvas.
 */
export const generateStoryImageDataUrl = (metadata: ExportMetadata): string => {
  const width = 1080;
  const height = 1920;
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;

  const context = canvas.getContext("2d");
  if (!context) {
    throw new Error("Não foi possível inicializar o contexto do canvas.");
  }

  const gradient = context.createLinearGradient(0, 0, width, height);
  gradient.addColorStop(0, "#0f172a");
  gradient.addColorStop(1, "#1e293b");
  context.fillStyle = gradient;
  context.fillRect(0, 0, width, height);

  context.fillStyle = "#f8fafc";
  context.font = "bold 62px Inter, Arial, sans-serif";
  context.fillText(metadata.titulo, 72, 170);

  context.fillStyle = "#cbd5e1";
  context.font = "500 40px Inter, Arial, sans-serif";
  context.fillText(`Versão ${metadata.versao}`, 72, 240);

  context.fillStyle = "#38bdf8";
  context.font = "700 54px Inter, Arial, sans-serif";
  context.fillText(`População 2026: ${metadata.populacao.toLocaleString("pt-BR")}`, 72, 410);

  context.fillStyle = "#facc15";
  context.fillText(`Eleitorado 2026: ${metadata.eleitorado.toLocaleString("pt-BR")}`, 72, 500);

  context.fillStyle = "#e2e8f0";
  context.font = "400 34px Inter, Arial, sans-serif";
  context.fillText(`Referência: ${metadata.referencia}`, 72, 620);

  context.fillStyle = "#94a3b8";
  context.font = "400 30px Inter, Arial, sans-serif";
  context.fillText("Observatório Eleitoral Águas Lindas de Goiás", 72, 1800);

  return canvas.toDataURL("image/png");
};

const buttonClassName =
  "inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-800 shadow-sm transition hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2";

/**
 * Ações de exportação para datasets e metadados do observatório.
 */
export function DataExportActions({ rows, metadata }: DataExportActionsProps) {
  const [status, setStatus] = useState<string>("");

  const metadataText = useMemo(
    () =>
      [
        `Título: ${metadata.titulo}`,
        `Versão: ${metadata.versao}`,
        `População 2026: ${metadata.populacao.toLocaleString("pt-BR")}`,
        `Eleitorado 2026: ${metadata.eleitorado.toLocaleString("pt-BR")}`,
        `Referência: ${metadata.referencia}`,
      ].join("\n"),
    [metadata],
  );

  const handleExportCsv = () => {
    const csv = buildCsvWithBom(rows);
    downloadBlob(csv, "observatorio-dados.csv", "text/csv;charset=utf-8;");
    setStatus("CSV exportado com sucesso.");
  };

  const handleExportStory = () => {
    const dataUrl = generateStoryImageDataUrl(metadata);
    const anchor = document.createElement("a");
    anchor.href = dataUrl;
    anchor.download = "observatorio-story.png";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setStatus("Imagem para stories gerada com sucesso.");
  };

  const handleCopyMetadata = async () => {
    await navigator.clipboard.writeText(metadataText);
    setStatus("Metadados copiados para a área de transferência.");
  };

  return (
    <section
      aria-labelledby="titulo-exportacao"
      className="rounded-2xl border border-slate-200 bg-slate-50 p-6 shadow-sm"
    >
      <h3 id="titulo-exportacao" className="text-xl font-bold text-slate-900">
        Exportação de dados e metadados
      </h3>
      <p className="mt-1 text-sm text-slate-600">
        Exporte CSV com BOM UTF-8, gere arte para stories e copie o resumo técnico.
      </p>

      <div className="mt-4 flex flex-wrap gap-3">
        <button type="button" onClick={handleExportCsv} className={buttonClassName}>
          <Download size={16} aria-hidden="true" />
          Exportar CSV (UTF-8 BOM)
        </button>

        <button type="button" onClick={handleExportStory} className={buttonClassName}>
          <ImageIcon size={16} aria-hidden="true" />
          Gerar imagem para stories
        </button>

        <button type="button" onClick={handleCopyMetadata} className={buttonClassName}>
          <Copy size={16} aria-hidden="true" />
          Copiar metadados
        </button>

        <button
          type="button"
          onClick={handleCopyMetadata}
          className={buttonClassName}
          aria-label="Copiar metadados para compartilhamento"
        >
          <Share2 size={16} aria-hidden="true" />
          Compartilhar resumo
        </button>
      </div>

      <p className="mt-3 text-sm text-blue-800" role="status" aria-live="polite">
        {status}
      </p>
    </section>
  );
}

export default DataExportActions;
