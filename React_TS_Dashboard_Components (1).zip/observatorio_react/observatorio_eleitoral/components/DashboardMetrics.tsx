import { Activity, Gauge, Users, Vote } from "lucide-react";
import { useMemo } from "react";
import { observatorioData } from "../data/observatorioData";
import type { ObservatorioData } from "../types/observatorio";

/** Ponto de um gráfico de linha temporal. */
export interface LineChartPoint {
  label: string;
  value: number;
}

export interface LineChartSvgProps {
  /** Pontos ordenados por tempo (label = ano/período). */
  points: LineChartPoint[];
  /** Largura do viewBox. */
  width?: number;
  /** Altura do viewBox. */
  height?: number;
  /** Cor da linha (classe de preenchimento SVG). */
  strokeClassName?: string;
  /** Cor dos marcadores de ponto. */
  pointClassName?: string;
  /** Formata o valor exibido nos rótulos. */
  formatValue?: (value: number) => string;
}

/** Converte pontos em coordenadas SVG com escala automática. */
export const buildLineChartGeometry = (
  points: LineChartPoint[],
  width: number,
  height: number,
): Array<{ x: number; y: number; label: string; value: number }> => {
  const padLeft = 10;
  const padRight = 10;
  const padTop = 20;
  const padBottom = 22;

  const values = points.map((point) => point.value);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;

  return points.map((point, index) => {
    const x =
      points.length === 1
        ? (padLeft + width - padRight) / 2
        : padLeft + (index / (points.length - 1)) * (width - padLeft - padRight);
    const y = padTop + (1 - (point.value - min) / range) * (height - padTop - padBottom);
    return { x, y, label: point.label, value: point.value };
  });
};

/** Constrói um caminho suave (Catmull-Rom → Bézier) pelos pontos. */
export const buildSmoothPath = (points: Array<{ x: number; y: number }>): string => {
  if (points.length < 2) return "";
  if (points.length === 2) {
    return `M ${points[0].x} ${points[0].y} L ${points[1].x} ${points[1].y}`;
  }
  let d = `M ${points[0].x} ${points[0].y}`;
  for (let i = 0; i < points.length - 1; i += 1) {
    const p0 = points[i - 1] ?? points[i];
    const p1 = points[i];
    const p2 = points[i + 1];
    const p3 = points[i + 2] ?? p2;
    const cp1x = p1.x + (p2.x - p0.x) / 6;
    const cp1y = p1.y + (p2.y - p0.y) / 6;
    const cp2x = p2.x - (p3.x - p1.x) / 6;
    const cp2y = p2.y - (p3.y - p1.y) / 6;
    d += ` C ${cp1x.toFixed(2)} ${cp1y.toFixed(2)}, ${cp2x.toFixed(2)} ${cp2y.toFixed(2)}, ${p2.x.toFixed(2)} ${p2.y.toFixed(2)}`;
  }
  return d;
};

/** Gráfico de linha temporal em SVG puro (sem bibliotecas externas). */
export function LineChartSvg({
  points,
  width = 400,
  height = 130,
  strokeClassName = "stroke-sky-500",
  pointClassName = "fill-amber-400",
  formatValue = (value) => value.toLocaleString("pt-BR"),
}: LineChartSvgProps) {
  const geometry = useMemo(
    () => buildLineChartGeometry(points, width, height),
    [points, width, height],
  );

  if (geometry.length === 0) return null;

  return (
    <svg
      viewBox={`0 0 ${width} ${height}`}
      className="h-auto w-full"
      role="img"
      aria-label={`Gráfico de linha com ${points.length} pontos`}
    >
      <line
        x1="10"
        y1={height - 22}
        x2={width - 10}
        y2={height - 22}
        className="stroke-slate-200 dark:stroke-slate-700"
        strokeWidth="1"
      />
      <path
        d={buildSmoothPath(geometry)}
        fill="none"
        className={strokeClassName}
        strokeWidth="3"
        strokeLinecap="round"
      />
      {geometry.map((point) => (
        <g key={point.label}>
          <circle cx={point.x} cy={point.y} r="5" className={pointClassName} />
          <text
            x={point.x - 18}
            y={point.y - 10}
            fontSize="9"
            className="fill-slate-500 dark:fill-slate-400"
          >
            {formatValue(point.value)} {point.label}
          </text>
        </g>
      ))}
    </svg>
  );
}

export interface DashboardMetricsProps {
  /** Dados do observatório (padrão: base canônica). */
  data?: ObservatorioData;
}

/**
 * Cards de indicadores principais (População, Eleitorado, Inclusão, Densidade)
 * e gráficos de linha temporal em SVG puro (Crescimento 2022-2026 e Eleitorado 2018-2026).
 */
export function DashboardMetrics({ data = observatorioData }: DashboardMetricsProps) {
  const { indicadoresMunicipais, estatisticasEleitorais, seriesTemporais } = data;

  const diffPop = indicadoresMunicipais.pop2026 - indicadoresMunicipais.pop2022;
  const crescimentoPopPct = (diffPop / indicadoresMunicipais.pop2022) * 100;
  const diffEleitorado = estatisticasEleitorais.eleitorado2026TreGo - estatisticasEleitorais.eleitorado2018;
  const crescimentoEleitoradoPct = (diffEleitorado / estatisticasEleitorais.eleitorado2018) * 100;
  const inclusaoPct = (estatisticasEleitorais.eleitorado2026TreGo / indicadoresMunicipais.pop2026) * 100;

  const cards = [
    {
      label: "População 2022→2026",
      value: `${indicadoresMunicipais.pop2022.toLocaleString("pt-BR")} → ${indicadoresMunicipais.pop2026.toLocaleString("pt-BR")}`,
      sub: `+${diffPop.toLocaleString("pt-BR")} • +${crescimentoPopPct.toFixed(2)}% • (249978-225693)/225693*100`,
      icon: Users,
      accentClassName: "text-sky-600 dark:text-sky-400",
      barClassName: "bg-sky-500",
    },
    {
      label: "Eleitorado 2018→2026",
      value: `${estatisticasEleitorais.eleitorado2018.toLocaleString("pt-BR")} → ${estatisticasEleitorais.eleitorado2026TreGo.toLocaleString("pt-BR")}`,
      sub: `+${diffEleitorado.toLocaleString("pt-BR")} • +${crescimentoEleitoradoPct.toFixed(1)}% • (125062-95200)/95200*100`,
      icon: Vote,
      accentClassName: "text-violet-600 dark:text-violet-400",
      barClassName: "bg-violet-500",
    },
    {
      label: "Inclusão eleitoral",
      value: `${inclusaoPct.toFixed(2)}%`,
      sub: `125062/249978*100 • discrepância ${estatisticasEleitorais.discrepanciaTreVsTse} • alta inclusão`,
      icon: Activity,
      accentClassName: "text-emerald-600 dark:text-emerald-400",
      barClassName: "bg-emerald-500",
    },
    {
      label: "Densidade demográfica",
      value: `${indicadoresMunicipais.densidadeHabKm2.toLocaleString("pt-BR")} hab/km²`,
      sub: `249978/191.8 • 4º GO • ${indicadoresMunicipais.areaKm2.toLocaleString("pt-BR")} km²`,
      icon: Gauge,
      accentClassName: "text-amber-600 dark:text-amber-400",
      barClassName: "bg-amber-500",
    },
  ];

  const pontosPopulacao: LineChartPoint[] = seriesTemporais.populacao.map((ponto) => ({
    label: String(ponto.ano),
    value: ponto.valor,
  }));

  const pontosEleitorado: LineChartPoint[] = [
    { label: "2018", value: estatisticasEleitorais.eleitorado2018 },
    { label: "2022", value: estatisticasEleitorais.eleitorado2022 },
    { label: "2024", value: estatisticasEleitorais.eleitorado2024 },
    { label: "2026", value: estatisticasEleitorais.eleitorado2026TreGo },
  ];

  return (
    <section
      aria-labelledby="titulo-dashboard"
      className="scroll-mt-20 px-4 py-10"
      id="dashboard"
    >
      <div className="mx-auto max-w-7xl">
        <div className="mb-5 flex flex-wrap items-end justify-between gap-4">
          <h2
            id="titulo-dashboard"
            className="text-2xl font-extrabold text-slate-900 dark:text-slate-50"
          >
            Dashboard Crescimento Acelerado V22 • +{indicadoresMunicipais.crescimento2010a2025}% 2010-2025 • +
            {crescimentoPopPct.toFixed(2)}% 2022-2026
          </h2>
          <span className="text-[11px] text-slate-500 dark:text-slate-400">
            IBGE 2025 {indicadoresMunicipais.pop2025.toLocaleString("pt-BR")} • World{" "}
            {(indicadoresMunicipais.popWorldSecundario ?? 0).toLocaleString("pt-BR")} secundário •{" "}
            {indicadoresMunicipais.areaKm2.toLocaleString("pt-BR")} km² •{" "}
            {indicadoresMunicipais.densidadeHabKm2.toLocaleString("pt-BR")} hab/km²
          </span>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {cards.map((card, index) => (
            <article
              key={card.label}
              className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900"
            >
              <div className="flex items-center justify-between gap-2">
                <p className="text-[11px] font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                  {card.label}
                </p>
                <card.icon size={16} className={card.accentClassName} aria-hidden="true" />
              </div>
              <p className={`mt-2 text-lg font-black ${card.accentClassName}`}>{card.value}</p>
              <p className="mt-1 text-[10px] leading-relaxed text-slate-500 dark:text-slate-400">
                {card.sub}
              </p>
              <div className="mt-3 h-1 overflow-hidden rounded-full bg-slate-200 dark:bg-slate-700">
                <div
                  className={`h-full rounded-full ${card.barClassName}`}
                  style={{ width: `${28 + index * 18}%` }}
                />
              </div>
            </article>
          ))}
        </div>

        <div className="mt-4 grid gap-4 lg:grid-cols-2">
          <article className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900">
            <h3 className="flex items-center gap-2 text-xs font-extrabold text-slate-800 dark:text-slate-200">
              <Activity size={16} className="text-sky-500" aria-hidden="true" />
              Crescimento Pop 2022-2026 com ponto 2025
            </h3>
            <LineChartSvg
              points={pontosPopulacao}
              strokeClassName="stroke-sky-500"
              pointClassName="fill-amber-400"
            />
            <p className="mt-2 text-[10px] text-slate-500 dark:text-slate-400">
              Diff perc reproduzível: (249978-225693)/225693*100 = {crescimentoPopPct.toFixed(2)}% • +
              {diffPop.toLocaleString("pt-BR")} hab
            </p>
          </article>

          <article className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900">
            <h3 className="flex items-center gap-2 text-xs font-extrabold text-slate-800 dark:text-slate-200">
              <Vote size={16} className="text-violet-500" aria-hidden="true" />
              Eleitorado 2018-2026 • TRE-GO/TSE
            </h3>
            <LineChartSvg
              points={pontosEleitorado}
              strokeClassName="stroke-violet-500"
              pointClassName="fill-amber-400"
            />
            <p className="mt-2 text-[10px] text-slate-500 dark:text-slate-400">
              +{crescimentoEleitoradoPct.toFixed(1)}% 2018-2026 • discrepância TRE vs TSE{" "}
              {estatisticasEleitorais.discrepanciaTreVsTse} • inclusão {inclusaoPct.toFixed(2)}% alta
            </p>
          </article>
        </div>
      </div>
    </section>
  );
}

export default DashboardMetrics;
