import { AlertTriangle, CheckCircle2, Radar, ShieldAlert } from "lucide-react";
import { useMemo, useState } from "react";
import { observatorioData } from "../data/observatorioData";
import type { ItemChecklistRadar, ObservatorioData } from "../types/observatorio";

export interface RadarAxis {
  key: string;
  label: string;
}

export interface RadarPoint {
  axis: RadarAxis;
  value: number;
}

export interface RadarGeometryOptions {
  centerX: number;
  centerY: number;
  radius: number;
}

export interface RadarGeometry {
  polygonPoints: string;
  axisLines: Array<{ x1: number; y1: number; x2: number; y2: number }>;
  axisLabels: Array<{ x: number; y: number; label: string }>;
  valueDots: Array<{ x: number; y: number; value: number; label: string }>;
  rings: Array<{ points: string; level: number }>;
}

export interface CandidateRadarDatum {
  axis: RadarAxis;
  candidato: string;
  percentualOriginal: number;
  value: number;
}

export const RADAR_AXES: RadarAxis[] = [
  { key: "keke", label: "Keké" },
  { key: "anderson", label: "Anderson" },
  { key: "ze-imperial", label: "Zé Imperial" },
  { key: "baiano", label: "Baiano" },
  { key: "cambao", label: "Cambão" },
  { key: "abadyas", label: "Abadyas" },
];

export const CHECKLIST_ITEMS: ItemChecklistRadar[] = observatorioData.checklistRadar72h;

export const normalizeRadarValue = (value: number, max: number): number => {
  if (max <= 0) return 0;
  return (value / max) * 100;
};

export const buildRadarGeometry = (
  points: RadarPoint[],
  options: RadarGeometryOptions,
): RadarGeometry => {
  const { centerX, centerY, radius } = options;
  const total = Math.max(points.length, 1);

  const toPolar = (angle: number, factor: number) => ({
    x: centerX + Math.cos(angle) * radius * factor,
    y: centerY + Math.sin(angle) * radius * factor,
  });

  const axisLines = points.map((_, index) => {
    const angle = -Math.PI / 2 + (index * 2 * Math.PI) / total;
    const end = toPolar(angle, 1);
    return { x1: centerX, y1: centerY, x2: end.x, y2: end.y, angle };
  });

  const axisLabels = points.map((point, index) => {
    const angle = -Math.PI / 2 + (index * 2 * Math.PI) / total;
    const labelPoint = toPolar(angle, 1.15);
    return { x: labelPoint.x, y: labelPoint.y, label: point.axis.label };
  });

  const valueDots = points.map((point, index) => {
    const angle = -Math.PI / 2 + (index * 2 * Math.PI) / total;
    const clampedValue = Math.max(0, Math.min(point.value, 100));
    const dotPoint = toPolar(angle, clampedValue / 100);
    return {
      x: dotPoint.x,
      y: dotPoint.y,
      value: clampedValue,
      label: point.axis.label,
    };
  });

  const polygonPoints = valueDots.map((dot) => `${dot.x.toFixed(2)},${dot.y.toFixed(2)}`).join(" ");

  const rings = [0.25, 0.5, 0.75, 1].map((level) => {
    const ringPoints = points
      .map((_, index) => {
        const angle = -Math.PI / 2 + (index * 2 * Math.PI) / total;
        const ringPoint = toPolar(angle, level);
        return `${ringPoint.x.toFixed(2)},${ringPoint.y.toFixed(2)}`;
      })
      .join(" ");

    return { points: ringPoints, level };
  });

  return {
    polygonPoints,
    axisLines: axisLines.map(({ x1, y1, x2, y2 }) => ({ x1, y1, x2, y2 })),
    axisLabels,
    valueDots,
    rings,
  };
};

export const buildCandidateRadarData = (data: ObservatorioData): CandidateRadarDatum[] => {
  const base = [...data.pesquisas.exataEstadual]
    .filter((item) => item.nome !== "Nenhum" && item.nome !== "NS/NR")
    .sort((a, b) => b.percentual - a.percentual)
    .slice(0, RADAR_AXES.length);

  const maxPercentual = Math.max(...base.map((item) => item.percentual), 1);

  return base.map((item, index) => ({
    axis: RADAR_AXES[index],
    candidato: item.nome,
    percentualOriginal: item.percentual,
    value: normalizeRadarValue(item.percentual, maxPercentual),
  }));
};

export interface PoliticalRadarProps {
  data?: ObservatorioData;
}

export function PoliticalRadar({ data = observatorioData }: PoliticalRadarProps) {
  const [checkedItems, setCheckedItems] = useState<Record<number, boolean>>({});

  const pesquisasEstaduaisOrdenadas = useMemo(
    () => [...data.pesquisas.exataEstadual].sort((a, b) => b.percentual - a.percentual),
    [data],
  );

  const candidatosRadar = useMemo(() => buildCandidateRadarData(data), [data]);

  const radarGeometry = useMemo(
    () =>
      buildRadarGeometry(
        candidatosRadar.map((item) => ({ axis: item.axis, value: item.value })),
        { centerX: 170, centerY: 170, radius: 120 },
      ),
    [candidatosRadar],
  );

  const checkedCount = Object.values(checkedItems).filter(Boolean).length;

  const toggleChecklistItem = (index: number): void => {
    setCheckedItems((current) => ({ ...current, [index]: !current[index] }));
  };

  return (
    <section id="radar" aria-labelledby="titulo-radar-politico" className="scroll-mt-20 px-4 py-10">
      <div className="mx-auto max-w-7xl space-y-6">
        <header className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900">
          <h2
            id="titulo-radar-politico"
            className="flex items-center gap-2 text-2xl font-extrabold text-slate-900 dark:text-slate-50"
          >
            <Radar size={22} className="text-sky-500" aria-hidden="true" />
            Radar Político
          </h2>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
            Comparativo de pesquisas e monitoramento da janela crítica entre 01/10 e 04/10 para prevenção de
            desinformação e deepfakes, com base na Resolução TSE nº 23.610 e monitoramento até 05/10.
          </p>
        </header>

        <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
          <article id="pesquisas" className="scroll-mt-20 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900">
            <h3 className="text-sm font-extrabold uppercase tracking-wide text-slate-600 dark:text-slate-300">
              Comparativo das pesquisas eleitorais
            </h3>

            <div className="mt-4 grid gap-4 lg:grid-cols-2">
              <div className="rounded-xl border border-slate-200 p-4 dark:border-slate-700">
                <p className="text-xs font-bold uppercase text-slate-500 dark:text-slate-400">
                  Exata estadual (amostra {data.pesquisas.amostraExata?.toLocaleString("pt-BR") ?? "N/D"})
                </p>
                <ul className="mt-2 space-y-2">
                  {pesquisasEstaduaisOrdenadas.slice(0, 6).map((item) => (
                    <li key={`estadual-${item.nome}`} className="flex items-center justify-between text-sm">
                      <span className="font-semibold text-slate-800 dark:text-slate-100">{item.nome}</span>
                      <span className="font-black text-sky-600 dark:text-sky-400">
                        {item.percentual.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}%
                      </span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="rounded-xl border border-slate-200 p-4 dark:border-slate-700">
                <p className="text-xs font-bold uppercase text-slate-500 dark:text-slate-400">
                  Exata federal (amostra {data.pesquisas.amostraExata?.toLocaleString("pt-BR") ?? "N/D"})
                </p>
                <ul className="mt-2 space-y-2">
                  {data.pesquisas.exataFederal.slice(0, 6).map((item) => (
                    <li key={`federal-${item.nome}`} className="flex items-center justify-between text-sm">
                      <span className="font-semibold text-slate-800 dark:text-slate-100">{item.nome}</span>
                      <span className="font-black text-violet-600 dark:text-violet-400">
                        {item.percentual.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}%
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800 dark:border-amber-900 dark:bg-amber-950/40 dark:text-amber-300">
              <p className="font-bold">
                Indecisão total: {data.pesquisas.indecisaoTotalPct?.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}% •
                IGAPE não sabe: {data.pesquisas.igapeNaoSabePct.toLocaleString("pt-BR", { minimumFractionDigits: 1 })}%
              </p>
              <p className="mt-1">
                Fonte dos dados de pesquisa: <strong>data/observatorioData.ts</strong> (base canônica extraída de
                Observatorio-V22-Ultra-Mais.html).
              </p>
            </div>
          </article>

          <article className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900">
            <h3 className="text-sm font-extrabold uppercase tracking-wide text-slate-600 dark:text-slate-300">
              Radar de força relativa dos candidatos (SVG nativo)
            </h3>

            <svg viewBox="0 0 340 340" className="mt-4 h-auto w-full" role="img" aria-label="Radar de candidatos">
              {radarGeometry.rings.map((ring) => (
                <polygon
                  key={`ring-${ring.level}`}
                  points={ring.points}
                  fill="none"
                  className="stroke-slate-200 dark:stroke-slate-700"
                  strokeWidth="1"
                />
              ))}

              {radarGeometry.axisLines.map((line, index) => (
                <line
                  key={`axis-${index}`}
                  x1={line.x1}
                  y1={line.y1}
                  x2={line.x2}
                  y2={line.y2}
                  className="stroke-slate-300 dark:stroke-slate-600"
                  strokeWidth="1"
                />
              ))}

              <polygon
                points={radarGeometry.polygonPoints}
                className="fill-sky-400/25 stroke-sky-500 dark:fill-sky-400/20 dark:stroke-sky-400"
                strokeWidth="2"
              />

              {radarGeometry.valueDots.map((dot) => (
                <g key={`dot-${dot.label}`}>
                  <circle cx={dot.x} cy={dot.y} r="4" className="fill-amber-400" />
                  <text
                    x={dot.x + 6}
                    y={dot.y - 6}
                    fontSize="9"
                    className="fill-slate-600 dark:fill-slate-300"
                  >
                    {dot.value.toFixed(0)}
                  </text>
                </g>
              ))}

              {radarGeometry.axisLabels.map((label) => (
                <text
                  key={`label-${label.label}`}
                  x={label.x}
                  y={label.y}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  fontSize="10"
                  className="fill-slate-700 dark:fill-slate-200"
                >
                  {label.label}
                </text>
              ))}
            </svg>

            <ul className="mt-4 space-y-2 text-xs text-slate-600 dark:text-slate-300">
              {candidatosRadar.map((item) => (
                <li key={`radar-${item.candidato}`} className="flex items-center justify-between">
                  <span>{item.candidato}</span>
                  <span className="font-bold">
                    {item.percentualOriginal.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}%
                  </span>
                </li>
              ))}
            </ul>
          </article>
        </div>

        <article className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900">
          <h3 className="flex items-center gap-2 text-sm font-extrabold uppercase tracking-wide text-slate-600 dark:text-slate-300">
            <ShieldAlert size={16} className="text-rose-500" aria-hidden="true" />
            Checklist 72h sensíveis à desinformação/deepfakes (01/10 a 04/10)
          </h3>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Itens marcados: {checkedCount}/{CHECKLIST_ITEMS.length} • Referência legal central: TSE Res. 23.610 •
            monitoramento operacional até 05/10.
          </p>

          <ul className="mt-4 space-y-2">
            {CHECKLIST_ITEMS.map((item, index) => {
              const checked = Boolean(checkedItems[index]);
              return (
                <li key={`${item.evento}-${item.dataReferencia}`}>
                  <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-slate-200 p-3 transition hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800/40">
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => toggleChecklistItem(index)}
                      className="mt-1 h-4 w-4 rounded border-slate-300 text-sky-600 focus:ring-sky-500 dark:border-slate-600"
                    />
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center gap-2 text-sm font-semibold text-slate-800 dark:text-slate-100">
                        {checked ? (
                          <CheckCircle2 size={14} className="text-emerald-500" aria-hidden="true" />
                        ) : (
                          <AlertTriangle size={14} className="text-amber-500" aria-hidden="true" />
                        )}
                        {item.evento}
                      </span>
                      <span className="mt-1 block text-xs text-slate-500 dark:text-slate-400">
                        {item.dataReferencia} • {item.marcador} • {item.baseLegalOuFonte ?? "Sem referência"}
                      </span>
                    </span>
                  </label>
                </li>
              );
            })}
          </ul>
        </article>
      </div>
    </section>
  );
}

export default PoliticalRadar;
