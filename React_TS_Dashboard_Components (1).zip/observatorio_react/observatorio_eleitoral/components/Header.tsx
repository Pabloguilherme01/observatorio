import { Moon, Search, Sun, X } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { observatorioData } from "../data/observatorioData";

/** Item de navegação por âncora do cabeçalho. */
export interface NavItem {
  id: string;
  label: string;
}

/** Item pesquisável no modal de busca (Ctrl+K). */
export interface SearchItem {
  id: string;
  label: string;
  descricao: string;
  anchor: string;
}

/** Âncoras padrão das 13 seções do observatório. */
export const NAV_ITEMS: NavItem[] = [
  { id: "dashboard", label: "Dashboard" },
  { id: "comparativo", label: "Entorno" },
  { id: "eleitorado", label: "Eleitorado" },
  { id: "pesquisas", label: "Pesquisas" },
  { id: "transporte", label: "Transporte" },
  { id: "saneamento", label: "Saneamento" },
  { id: "saude", label: "Saúde" },
  { id: "educacao", label: "Educação" },
  { id: "economia", label: "Economia" },
  { id: "seguranca", label: "Segurança" },
  { id: "regional", label: "Regional" },
  { id: "radar", label: "Radar" },
  { id: "central", label: "Central" },
  { id: "evidencias", label: "Evidências" },
];

/** Chave de persistência do tema (compatível com a base canônica v22). */
export const THEME_STORAGE_KEY = "obs_theme_v22";

/** Rola suavemente até a âncora indicada. */
export const scrollToAnchor = (anchor: string): void => {
  const element = document.getElementById(anchor);
  if (element) {
    element.scrollIntoView({ behavior: "smooth", block: "start" });
  }
};

/** Constrói os itens pesquisáveis padrão a partir da base de dados. */
export const buildDefaultSearchItems = (): SearchItem[] => {
  const { indicadoresMunicipais, estatisticasEleitorais, saneamento, saude, transporte, economia } =
    observatorioData;
  const inclusao = (estatisticasEleitorais.eleitorado2026TreGo / indicadoresMunicipais.pop2026) * 100;

  return [
    {
      id: "populacao",
      label: "População 2026",
      descricao: `${indicadoresMunicipais.pop2026.toLocaleString("pt-BR")} hab • IBGE`,
      anchor: "dashboard",
    },
    {
      id: "eleitorado",
      label: "Eleitorado 2026",
      descricao: `${estatisticasEleitorais.eleitorado2026TreGo.toLocaleString("pt-BR")} • TRE-GO 28ª Zona`,
      anchor: "eleitorado",
    },
    {
      id: "inclusao",
      label: "Inclusão eleitoral",
      descricao: `${inclusao.toFixed(2)}% • 125062/249978*100`,
      anchor: "eleitorado",
    },
    {
      id: "densidade",
      label: "Densidade demográfica",
      descricao: `${indicadoresMunicipais.densidadeHabKm2} hab/km² • 249978/191.8`,
      anchor: "dashboard",
    },
    {
      id: "tarifa",
      label: "Tarifa Brasília",
      descricao: `R$ ${transporte.tarifaBrasilia.toFixed(2)} • ANTT Delib 40`,
      anchor: "transporte",
    },
    {
      id: "saneamento",
      label: "Saneamento",
      descricao: `Esgoto ${saneamento.esgoto2024Pct}% • ${saneamento.internacoesAgua} internações`,
      anchor: "saneamento",
    },
    {
      id: "healgo",
      label: "HEALGO",
      descricao: `${saude.healgoLeitos} → ${saude.healgoLeitosProjetado} leitos • ${saude.healgoAtendimentosAno.toLocaleString("pt-BR")} atend/ano`,
      anchor: "saude",
    },
    {
      id: "pib-ride",
      label: "PIB RIDE-DF",
      descricao: `R$ ${economia.pibRideDfBi.toLocaleString("pt-BR")} bi • +${economia.crescimentoRideDfPct ?? 0}%`,
      anchor: "economia",
    },
    {
      id: "radar",
      label: "Radar eleitoral",
      descricao: "23/09-04/10 • 72h sensível IA",
      anchor: "radar",
    },
  ];
};

export interface HeaderProps {
  /** Itens de navegação por âncora. */
  navItems?: NavItem[];
  /** Itens pesquisáveis no modal Ctrl+K (padrão: derivados da base). */
  searchItems?: SearchItem[];
}

/**
 * Cabeçalho fixo com alternância Dark/Light, navegação por âncoras,
 * seção ativa por rolagem e modal de busca acionado por Ctrl+K ou "/".
 */
export function Header({ navItems = NAV_ITEMS, searchItems }: HeaderProps) {
  const [theme, setTheme] = useState<"dark" | "light">(() => {
    if (typeof window === "undefined") return "dark";
    const stored = window.localStorage.getItem(THEME_STORAGE_KEY);
    return stored === "light" ? "light" : "dark";
  });
  const [activeSection, setActiveSection] = useState<string>("dashboard");
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [highlightedIndex, setHighlightedIndex] = useState(0);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const items = useMemo<SearchItem[]>(
    () => searchItems ?? buildDefaultSearchItems(),
    [searchItems],
  );

  const filteredItems = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return items;
    return items.filter(
      (item) =>
        item.label.toLowerCase().includes(normalized) ||
        item.descricao.toLowerCase().includes(normalized),
    );
  }, [items, query]);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    window.localStorage.setItem(THEME_STORAGE_KEY, theme);
  }, [theme]);

  useEffect(() => {
    const onScroll = () => {
      const sections = document.querySelectorAll<HTMLElement>("section[id]");
      let current = "dashboard";
      sections.forEach((section) => {
        if (section.getBoundingClientRect().top <= 120) current = section.id;
      });
      setActiveSection(current);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setSearchOpen(true);
      }
      if (event.key === "/" && !searchOpen) {
        event.preventDefault();
        setSearchOpen(true);
      }
      if (event.key === "Escape") setSearchOpen(false);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [searchOpen]);

  useEffect(() => {
    if (searchOpen) {
      setQuery("");
      setHighlightedIndex(0);
      window.setTimeout(() => searchInputRef.current?.focus(), 0);
    }
  }, [searchOpen]);

  const closeSearch = () => setSearchOpen(false);

  const handleSelect = (item: SearchItem) => {
    closeSearch();
    scrollToAnchor(item.anchor);
  };

  const handleSearchKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "ArrowDown") {
      event.preventDefault();
      setHighlightedIndex((index) => Math.min(index + 1, filteredItems.length - 1));
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      setHighlightedIndex((index) => Math.max(index - 1, 0));
    } else if (event.key === "Enter" && filteredItems[highlightedIndex]) {
      event.preventDefault();
      handleSelect(filteredItems[highlightedIndex]);
    }
  };

  const { metadados, indicadoresMunicipais, estatisticasEleitorais, economia } = observatorioData;
  const taxaHomicidios =
    observatorioData.rankingHomicidiosGoias.find((item) => item.nome.includes("Águas Lindas"))?.taxa ??
    18.7;

  return (
    <>
      <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/90 backdrop-blur dark:border-slate-800 dark:bg-slate-950/85">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-3 px-4">
          <a
            href="#dashboard"
            onClick={(event) => {
              event.preventDefault();
              scrollToAnchor("dashboard");
            }}
            className="flex min-w-0 items-center gap-3"
            aria-label="Ir para o início do observatório"
          >
            <span
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-sky-500 to-amber-400 text-sm font-black text-slate-900"
              aria-hidden="true"
            >
              ds
            </span>
            <span className="min-w-0">
              <span className="block truncate text-sm font-black tracking-tight text-slate-900 dark:text-slate-50">
                Observatório Águas Lindas 2026 {metadados.versao}
              </span>
              <span className="block truncate text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                {metadados.secaoTotal} seções • {estatisticasEleitorais.eleitorado2026TreGo.toLocaleString("pt-BR")} eleit •{" "}
                {indicadoresMunicipais.pop2026.toLocaleString("pt-BR")} hab • RIDE-DF{" "}
                {economia.pibRideDfBi.toLocaleString("pt-BR")}bi • Polo {economia.poloIndustrialEmpresas} •{" "}
                {taxaHomicidios}/100k
              </span>
            </span>
          </a>

          <nav
            className="flex max-w-[62vw] items-center gap-1.5 overflow-x-auto"
            aria-label="Navegação por seções"
          >
            {navItems.map((item) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                onClick={(event) => {
                  event.preventDefault();
                  scrollToAnchor(item.id);
                }}
                className={`whitespace-nowrap rounded-full border px-2.5 py-1.5 text-[11px] font-extrabold uppercase transition ${
                  activeSection === item.id
                    ? "border-amber-400 bg-amber-400/15 text-amber-600 dark:text-amber-400"
                    : "border-slate-200 text-slate-500 hover:border-slate-300 hover:text-slate-700 dark:border-slate-700 dark:text-slate-400 dark:hover:text-slate-200"
                }`}
                aria-current={activeSection === item.id ? "true" : undefined}
              >
                {item.label}
              </a>
            ))}

            <button
              type="button"
              onClick={() => setTheme((current) => (current === "dark" ? "light" : "dark"))}
              className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-slate-200 text-slate-600 transition hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
              aria-label={theme === "dark" ? "Ativar tema claro" : "Ativar tema escuro"}
              title={theme === "dark" ? "Tema claro" : "Tema escuro"}
            >
              {theme === "dark" ? <Sun size={16} aria-hidden="true" /> : <Moon size={16} aria-hidden="true" />}
            </button>

            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              className="flex h-9 shrink-0 items-center gap-2 rounded-full border border-slate-200 px-3 text-xs font-semibold text-slate-600 transition hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
              aria-label="Abrir busca (Ctrl+K)"
            >
              <Search size={14} aria-hidden="true" />
              <span className="hidden sm:inline">Buscar</span>
              <kbd className="hidden rounded border border-slate-300 px-1 text-[9px] font-bold text-slate-400 md:inline dark:border-slate-600 dark:text-slate-500">
                Ctrl K
              </kbd>
            </button>
          </nav>
        </div>
      </header>

      {searchOpen && (
        <div
          className="fixed inset-0 z-[80] flex items-start justify-center bg-slate-900/60 p-4 pt-[12vh] backdrop-blur-sm"
          onClick={closeSearch}
          role="dialog"
          aria-modal="true"
          aria-label="Busca no observatório"
        >
          <div
            className="w-full max-w-lg overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl dark:border-slate-700 dark:bg-slate-900"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="flex items-center gap-3 border-b border-slate-200 px-4 py-3 dark:border-slate-700">
              <Search size={18} className="shrink-0 text-slate-400" aria-hidden="true" />
              <input
                ref={searchInputRef}
                value={query}
                onChange={(event) => {
                  setQuery(event.target.value);
                  setHighlightedIndex(0);
                }}
                onKeyDown={handleSearchKeyDown}
                placeholder="Buscar seções e indicadores…"
                className="w-full bg-transparent text-sm text-slate-900 outline-none placeholder:text-slate-400 dark:text-slate-100"
                aria-label="Termo de busca"
              />
              <button
                type="button"
                onClick={closeSearch}
                className="grid h-7 w-7 shrink-0 place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800 dark:hover:text-slate-200"
                aria-label="Fechar busca"
              >
                <X size={16} aria-hidden="true" />
              </button>
            </div>

            <ul className="max-h-80 overflow-y-auto p-2" role="listbox" aria-label="Resultados da busca">
              {filteredItems.map((item, index) => (
                <li key={item.id} role="option" aria-selected={index === highlightedIndex}>
                  <button
                    type="button"
                    onClick={() => handleSelect(item)}
                    onMouseEnter={() => setHighlightedIndex(index)}
                    className={`flex w-full items-center justify-between gap-3 rounded-xl px-3 py-2.5 text-left transition ${
                      index === highlightedIndex
                        ? "bg-sky-50 dark:bg-slate-800"
                        : "hover:bg-slate-50 dark:hover:bg-slate-800/60"
                    }`}
                  >
                    <span className="min-w-0">
                      <span className="block truncate text-sm font-semibold text-slate-900 dark:text-slate-100">
                        {item.label}
                      </span>
                      <span className="block truncate text-xs text-slate-500 dark:text-slate-400">
                        {item.descricao}
                      </span>
                    </span>
                    <span className="shrink-0 rounded border border-slate-200 px-1.5 py-0.5 text-[9px] font-bold uppercase text-slate-400 dark:border-slate-700 dark:text-slate-500">
                      #{item.anchor}
                    </span>
                  </button>
                </li>
              ))}
              {filteredItems.length === 0 && (
                <li className="px-3 py-6 text-center text-sm text-slate-500 dark:text-slate-400">
                  Nenhum resultado para “{query}”.
                </li>
              )}
            </ul>
          </div>
        </div>
      )}
    </>
  );
}

export default Header;
