import { useEffect, useState } from "react";
import { observatorioData } from "../data/observatorioData";

/** Resultado de um countdown regressivo. */
export interface CountdownResult {
  dias: number;
  horas: number;
  minutos: number;
  segundos: number;
  expirado: boolean;
}

/** Data-alvo da eleição: 04/10/2026 08:00 (horário de Brasília). */
export const ELECTION_TARGET_ISO = "2026-10-04T08:00:00-03:00";

/** Data-alvo do período sensível eleitoral: início da propaganda (23/09/2026). */
export const SENSITIVE_PERIOD_TARGET_ISO = "2026-09-23T00:00:00-03:00";

/** Calcula a diferença entre a data-alvo e o instante atual. */
export const calculateCountdown = (
  targetIso: string,
  now: number = Date.now(),
): CountdownResult => {
  const diff = new Date(targetIso).getTime() - now;
  const clamped = Math.max(0, diff);
  return {
    dias: Math.floor(clamped / 86_400_000),
    horas: Math.floor((clamped % 86_400_000) / 3_600_000),
    minutos: Math.floor((clamped % 3_600_000) / 60_000),
    segundos: Math.floor((clamped % 60_000) / 1000),
    expirado: diff <= 0,
  };
};

/** Hook de countdown regressivo atualizado a cada segundo. */
export const useCountdown = (targetIso: string): CountdownResult => {
  const [now, setNow] = useState<number>(() => Date.now());

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  return calculateCountdown(targetIso, now);
};

/** Formata um valor de countdown com dois dígitos. */
export const padCountdown = (value: number): string => String(value).padStart(2, "0");

export interface CountdownCardProps {
  /** Rótulo exibido acima dos dígitos. */
  label: string;
  /** Data-alvo em ISO 8601 com fuso. */
  targetIso: string;
  /** Nota complementar exibida abaixo dos dígitos. */
  note: string;
  /** Cor de destaque dos dígitos (classe Tailwind). */
  accentClassName?: string;
}

/** Card de contagem regressiva com dígitos em fonte monoespaçada. */
export function CountdownCard({
  label,
  targetIso,
  note,
  accentClassName = "text-sky-600 dark:text-sky-400",
}: CountdownCardProps) {
  const { dias, horas, minutos, segundos, expirado } = useCountdown(targetIso);

  const units = [
    { value: dias, label: "dias" },
    { value: horas, label: "horas" },
    { value: minutos, label: "min" },
    { value: segundos, label: "seg" },
  ];

  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900">
      <p className="text-[11px] font-bold uppercase tracking-[0.09em] text-slate-500 dark:text-slate-400">
        {label}
      </p>
      <div
        className={`mt-2 flex flex-wrap gap-2 font-mono text-3xl font-black tabular-nums ${accentClassName}`}
        role="timer"
        aria-live="polite"
        aria-label={`${label}: ${dias} dias, ${horas} horas, ${minutos} minutos e ${segundos} segundos`}
      >
        {expirado ? (
          <span className="text-base font-bold text-slate-500 dark:text-slate-400">
            Período encerrado
          </span>
        ) : (
          units.map((unit) => (
            <span key={unit.label} className="flex items-baseline gap-1">
              <span>{padCountdown(unit.value)}</span>
              <span className="text-[10px] font-bold uppercase text-slate-400 dark:text-slate-500">
                {unit.label}
              </span>
            </span>
          ))
        )}
      </div>
      <p className="mt-2 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">{note}</p>
    </div>
  );
}

export interface HeroCountdownProps {
  /** Dados do observatório (padrão: base canônica). */
  data?: typeof observatorioData;
}

/**
 * Hero com badges de destaque, título principal e contadores regressivos
 * para a eleição (04/10/2026 08:00) e para o período sensível eleitoral (23/09).
 */
export function HeroCountdown({ data = observatorioData }: HeroCountdownProps) {
  const { indicadoresMunicipais, estatisticasEleitorais, economia } = data;
  const diffPop = indicadoresMunicipais.pop2026 - indicadoresMunicipais.pop2022;
  const crescimentoPopPct = (diffPop / indicadoresMunicipais.pop2022) * 100;
  const taxaHomicidios =
    data.rankingHomicidiosGoias.find((item) => item.nome.includes("Águas Lindas"))?.taxa ?? 18.71;

  const badges = [
    {
      texto: `4º mais populoso GO • ${indicadoresMunicipais.pop2022.toLocaleString("pt-BR")}→${indicadoresMunicipais.pop2026.toLocaleString("pt-BR")} +${crescimentoPopPct.toFixed(2)}%`,
      className: "border-sky-200 bg-sky-50 text-sky-700 dark:border-sky-900 dark:bg-sky-950 dark:text-sky-300",
    },
    {
      texto: `6º eleitorado GO • 3ª zona • ${estatisticasEleitorais.eleitorado2026TreGo.toLocaleString("pt-BR")}`,
      className: "border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-900 dark:bg-amber-950 dark:text-amber-300",
    },
    {
      texto: `PIB RIDE-DF R$${economia.pibRideDfBi.toLocaleString("pt-BR")}bi +${economia.crescimentoRideDfPct ?? 0}% • 6ª Entorno`,
      className: "border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-900 dark:bg-emerald-950 dark:text-emerald-300",
    },
    {
      texto: `Taxa homicídios ${taxaHomicidios}/100k • 8º GO • 5/10 Entorno`,
      className: "border-rose-200 bg-rose-50 text-rose-700 dark:border-rose-900 dark:bg-rose-950 dark:text-rose-300",
    },
    {
      texto: `Polo Sol Nascente ${economia.poloIndustrialEmpresas} empresas chinesas ${economia.poloIndustrialEmpregos.toLocaleString("pt-BR")} empregos`,
      className: "border-violet-200 bg-violet-50 text-violet-700 dark:border-violet-900 dark:bg-violet-950 dark:text-violet-300",
    },
  ];

  return (
    <section
      aria-labelledby="titulo-hero"
      className="border-b border-slate-200 bg-slate-50/60 px-4 py-12 dark:border-slate-800 dark:bg-slate-950"
    >
      <div className="mx-auto grid max-w-7xl gap-6 lg:grid-cols-[1.25fr_0.75fr]">
        <div>
          <div className="mb-4 flex flex-wrap gap-2">
            {badges.map((badge) => (
              <span
                key={badge.texto}
                className={`rounded-full border px-3 py-1 text-[11px] font-bold ${badge.className}`}
              >
                {badge.texto}
              </span>
            ))}
          </div>

          <h1
            id="titulo-hero"
            className="text-4xl font-black leading-[0.95] tracking-tight text-slate-900 sm:text-5xl lg:text-6xl dark:text-slate-50"
          >
            Observatório Eleitoral
            <br />
            <span className="text-sky-600 dark:text-sky-400">Águas Lindas de Goiás 2026</span>
            <span className="mt-3 block text-base font-semibold tracking-tight text-slate-500 dark:text-slate-400">
              v22 Ultra • TGC {indicadoresMunicipais.tgc2025a2026}% 2025-2026 • crescimento 2010-2025 +
              {indicadoresMunicipais.crescimento2010a2025}% IBGE • diff 2022-2026 +{diffPop.toLocaleString("pt-BR")}{" "}
              +{crescimentoPopPct.toFixed(2)}% • worldpopulationreview{" "}
              {(indicadoresMunicipais.popWorldSecundario ?? 0).toLocaleString("pt-BR")} secundário •{" "}
              {((estatisticasEleitorais.eleitorado2026TreGo / indicadoresMunicipais.pop2026) * 100).toFixed(2)}%
              inclusão • R$11.43 tarifa 31% SM família 93.1% • {data.saneamento.internacoesAgua} internações água
            </span>
          </h1>

          <p className="mt-5 max-w-[70ch] text-sm leading-relaxed text-slate-600 dark:text-slate-400">
            Evolução do V21 com diagnóstico demografia-custo-saúde. 13 seções + calculadoras família 1-3p,
            comparativa rotas Brasília vs Taguatinga/Ceilândia, economia Taguatinga, slider HEALGO 164→298
            leitos, polo setores drones/motos/solar/eletrônicos, ranking Atlas Violência metodologia MVCI,
            PIB RIDE-DF 416.6 bi 10.2% crescimento, contadores reproduzíveis, fontes auditáveis.
          </p>
        </div>

        <div className="flex flex-col gap-3">
          <CountdownCard
            label="Contagem eleição 04/10/2026 08:00 -03:00"
            targetIso={ELECTION_TARGET_ISO}
            note="Período sensível IA 01-04/10 72h • Res TSE 23.610 deepfake"
            accentClassName="text-sky-600 dark:text-sky-400"
          />

          <CountdownCard
            label="Período sensível eleitoral • Início propaganda 23/09"
            targetIso={SENSITIVE_PERIOD_TARGET_ISO}
            note="Radar 23/09-04/10 • D-11 • 72h sensível IA 01-04/10 • Res TSE 23.610 deepfake • monitoramento de desinformação até 05/10"
            accentClassName="text-amber-600 dark:text-amber-400"
          />
        </div>
      </div>
    </section>
  );
}

export default HeroCountdown;
