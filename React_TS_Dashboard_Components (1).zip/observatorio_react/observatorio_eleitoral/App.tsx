import { Search, X } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import DashboardMetrics from "./components/DashboardMetrics";
import DataExportActions, { type CsvRow, type ExportMetadata } from "./components/DataExportActions";
import Header, {
  NAV_ITEMS,
  THEME_STORAGE_KEY,
  buildDefaultSearchItems,
  scrollToAnchor,
  type SearchItem,
} from "./components/Header";
import HeroCountdown from "./components/HeroCountdown";
import PoliticalRadar from "./components/PoliticalRadar";
import SanitationHealthSection from "./components/SanitationHealthSection";
import TransportCalculator from "./components/TransportCalculator";
import { observatorioData } from "./data/observatorioData";

export interface QuickSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: SearchItem[];
}

export function QuickSearchModal({ isOpen, onClose, items }: QuickSearchModalProps) {
  const [query, setQuery] = useState<string>("");
  const [highlightedIndex, setHighlightedIndex] = useState<number>(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const filteredItems = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return items;
    return items.filter(
      (item) =>
        item.label.toLowerCase().includes(normalized) ||
        item.descricao.toLowerCase().includes(normalized) ||
        item.anchor.toLowerCase().includes(normalized),
    );
  }, [items, query]);

  useEffect(() => {
    if (isOpen) {
      setQuery("");
      setHighlightedIndex(0);
      window.setTimeout(() => inputRef.current?.focus(), 0);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const selectItem = (item: SearchItem): void => {
    onClose();
    scrollToAnchor(item.anchor);
  };

  return (
    <div
      className="fixed inset-0 z-[90] flex items-start justify-center bg-slate-900/60 p-4 pt-[12vh] backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Pesquisa rápida"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl dark:border-slate-700 dark:bg-slate-900"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="flex items-center gap-3 border-b border-slate-200 px-4 py-3 dark:border-slate-700">
          <Search size={18} className="shrink-0 text-slate-400" aria-hidden="true" />
          <input
            ref={inputRef}
            value={query}
            onChange={(event) => {
              setQuery(event.target.value);
              setHighlightedIndex(0);
            }}
            onKeyDown={(event) => {
              if (event.key === "ArrowDown") {
                event.preventDefault();
                setHighlightedIndex((index) => Math.min(index + 1, filteredItems.length - 1));
              } else if (event.key === "ArrowUp") {
                event.preventDefault();
                setHighlightedIndex((index) => Math.max(index - 1, 0));
              } else if (event.key === "Enter" && filteredItems[highlightedIndex]) {
                event.preventDefault();
                selectItem(filteredItems[highlightedIndex]);
              }
            }}
            placeholder="Pesquisar seção, indicador ou âncora..."
            className="w-full bg-transparent text-sm text-slate-900 outline-none placeholder:text-slate-400 dark:text-slate-100"
            aria-label="Pesquisar conteúdo"
          />
          <button
            type="button"
            onClick={onClose}
            className="grid h-7 w-7 place-items-center rounded-lg text-slate-400 transition hover:bg-slate-100 hover:text-slate-600 dark:hover:bg-slate-800 dark:hover:text-slate-200"
            aria-label="Fechar pesquisa"
          >
            <X size={16} aria-hidden="true" />
          </button>
        </div>

        <ul className="max-h-80 overflow-y-auto p-2" role="listbox" aria-label="Resultados da pesquisa">
          {filteredItems.map((item, index) => (
            <li key={item.id} role="option" aria-selected={index === highlightedIndex}>
              <button
                type="button"
                onClick={() => selectItem(item)}
                onMouseEnter={() => setHighlightedIndex(index)}
                className={`flex w-full items-center justify-between gap-3 rounded-xl px-3 py-2.5 text-left transition ${
                  index === highlightedIndex
                    ? "bg-sky-50 dark:bg-slate-800"
                    : "hover:bg-slate-50 dark:hover:bg-slate-800/60"
                }`}
              >
                <span className="min-w-0">
                  <span className="block truncate text-sm font-semibold text-slate-900 dark:text-slate-100">
                    {item.label}
                  </span>
                  <span className="block truncate text-xs text-slate-500 dark:text-slate-400">
                    {item.descricao}
                  </span>
                </span>
                <span className="shrink-0 rounded border border-slate-200 px-1.5 py-0.5 text-[9px] font-bold uppercase text-slate-400 dark:border-slate-700 dark:text-slate-500">
                  #{item.anchor}
                </span>
              </button>
            </li>
          ))}
          {filteredItems.length === 0 && (
            <li className="px-3 py-6 text-center text-sm text-slate-500 dark:text-slate-400">
              Nenhum resultado para “{query}”.
            </li>
          )}
        </ul>
      </div>
    </div>
  );
}

export function App() {
  const [theme, setTheme] = useState<"dark" | "light">(() => {
    if (typeof window === "undefined") return "dark";
    const storedTheme = window.localStorage.getItem(THEME_STORAGE_KEY);
    return storedTheme === "light" ? "light" : "dark";
  });

  const [searchOpen, setSearchOpen] = useState<boolean>(false);

  const quickSearchItems = useMemo<SearchItem[]>(() => {
    const defaults = buildDefaultSearchItems();
    const map = new Map<string, SearchItem>();

    defaults.forEach((item) => map.set(item.id, item));
    NAV_ITEMS.forEach((item) => {
      map.set(`nav-${item.id}`, {
        id: `nav-${item.id}`,
        label: item.label,
        descricao: `Navegar para seção ${item.label}`,
        anchor: item.id,
      });
    });

    return Array.from(map.values());
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark");
    window.localStorage.setItem(THEME_STORAGE_KEY, theme);
  }, [theme]);

  useEffect(() => {
    const syncFromStorage = (): void => {
      const storedTheme = window.localStorage.getItem(THEME_STORAGE_KEY);
      setTheme(storedTheme === "light" ? "light" : "dark");
    };

    const onStorage = (event: StorageEvent): void => {
      if (event.key === THEME_STORAGE_KEY) {
        syncFromStorage();
      }
    };

    window.addEventListener("storage", onStorage);

    const observer = new MutationObserver(() => {
      const nextTheme: "dark" | "light" = document.documentElement.classList.contains("dark")
        ? "dark"
        : "light";
      setTheme((current) => (current === nextTheme ? current : nextTheme));
    });

    observer.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });

    return () => {
      window.removeEventListener("storage", onStorage);
      observer.disconnect();
    };
  }, []);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent): void => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        event.stopImmediatePropagation();
        setSearchOpen(true);
      }
      if (event.key === "Escape") {
        setSearchOpen(false);
      }
    };

    window.addEventListener("keydown", onKeyDown, { capture: true });
    return () => window.removeEventListener("keydown", onKeyDown, { capture: true });
  }, []);

  const exportRows = useMemo<CsvRow[]>(
    () =>
      observatorioData.entornoDf.map((item) => ({
        municipio: item.nome,
        eleitorado: item.eleitorado,
        populacao: item.populacao,
        densidade_hab_km2: item.densidade ?? null,
        pib_bi: item.pibBi ?? null,
      })),
    [],
  );

  const exportMetadata = useMemo<ExportMetadata>(
    () => ({
      titulo: observatorioData.metadados.nome,
      versao: observatorioData.metadados.versao,
      populacao: observatorioData.indicadoresMunicipais.pop2026,
      eleitorado: observatorioData.estatisticasEleitorais.eleitorado2026TreGo,
      referencia: "Base canônica Observatorio-V22-Ultra-Mais.html",
    }),
    [],
  );

  const inclusaoEleitoralPct =
    (observatorioData.estatisticasEleitorais.eleitorado2026TreGo / observatorioData.indicadoresMunicipais.pop2026) *
    100;

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 transition-colors dark:bg-slate-950 dark:text-slate-100">
      <Header navItems={NAV_ITEMS} searchItems={quickSearchItems} />
      <HeroCountdown data={observatorioData} />

      <main className="pb-16">
        <DashboardMetrics data={observatorioData} />

        <section id="comparativo" className="scroll-mt-20 px-4 py-10" aria-labelledby="titulo-comparativo">
          <div className="mx-auto max-w-7xl rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900">
            <h2 id="titulo-comparativo" className="text-xl font-extrabold text-slate-900 dark:text-slate-50">
              Comparativo regional (Entorno DF)
            </h2>
            <div className="mt-4 grid gap-3 md:grid-cols-3">
              {observatorioData.entornoDf.map((item) => (
                <article key={item.nome} className="rounded-xl border border-slate-200 p-4 dark:border-slate-700">
                  <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100">{item.nome}</h3>
                  <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                    Eleitorado: {item.eleitorado.toLocaleString("pt-BR")}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    População: {item.populacao.toLocaleString("pt-BR")}
                  </p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    PIB: R$ {item.pibBi?.toLocaleString("pt-BR") ?? "N/D"} bi
                  </p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="eleitorado" className="scroll-mt-20 px-4 py-10" aria-labelledby="titulo-eleitorado">
          <div className="mx-auto max-w-7xl rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900">
            <h2 id="titulo-eleitorado" className="text-xl font-extrabold text-slate-900 dark:text-slate-50">
              Eleitorado e inclusão
            </h2>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
              TRE-GO 28ª Zona: {observatorioData.estatisticasEleitorais.eleitorado2026TreGo.toLocaleString("pt-BR")} eleitores,
              inclusão eleitoral de {inclusaoEleitoralPct.toFixed(2)}% e comparecimento de {observatorioData.estatisticasEleitorais.comparecimentoPct?.toLocaleString("pt-BR", { minimumFractionDigits: 2 })}% em 2024.
            </p>
          </div>
        </section>

        <section id="transporte" className="scroll-mt-20 px-4 py-10" aria-labelledby="titulo-transporte-wrapper">
          <div className="mx-auto max-w-7xl">
            <h2 id="titulo-transporte-wrapper" className="mb-4 text-xl font-extrabold text-slate-900 dark:text-slate-50">
              Transporte e mobilidade
            </h2>
            <TransportCalculator
              defaultTarifa={observatorioData.transporte.tarifaBrasilia}
              defaultDiasUteis={observatorioData.transporte.diasUteisPadrao}
              defaultPessoas={3}
              salarioMinimo={observatorioData.transporte.salarioMinimo}
            />
          </div>
        </section>

        <section id="saneamento" className="scroll-mt-20">
          <div id="saude" className="scroll-mt-20">
            <SanitationHealthSection data={observatorioData} />
          </div>
        </section>

        <section id="educacao" className="scroll-mt-20 px-4 py-10" aria-labelledby="titulo-educacao">
          <div className="mx-auto max-w-7xl rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900">
            <h2 id="titulo-educacao" className="text-xl font-extrabold text-slate-900 dark:text-slate-50">
              Educação
            </h2>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
              IDEB anos iniciais {observatorioData.educacao.idebAnosIniciais.toLocaleString("pt-BR", { minimumFractionDigits: 1 })} •
              anos finais {observatorioData.educacao.idebAnosFinais.toLocaleString("pt-BR", { minimumFractionDigits: 1 })} •
              IDHM {observatorioData.educacao.idhm.toLocaleString("pt-BR", { minimumFractionDigits: 3 })}.
            </p>
          </div>
        </section>

        <section id="economia" className="scroll-mt-20 px-4 py-10" aria-labelledby="titulo-economia">
          <div className="mx-auto max-w-7xl rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900">
            <h2 id="titulo-economia" className="text-xl font-extrabold text-slate-900 dark:text-slate-50">
              Economia
            </h2>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
              PIB municipal R$ {observatorioData.economia.pibBi.toLocaleString("pt-BR")} bi • PIB RIDE-DF R$
              {observatorioData.economia.pibRideDfBi.toLocaleString("pt-BR")} bi • LOA 2026 de R$
              {observatorioData.economia.loa2026.toLocaleString("pt-BR", { maximumFractionDigits: 2 })}.
            </p>
          </div>
        </section>

        <section id="seguranca" className="scroll-mt-20 px-4 py-10" aria-labelledby="titulo-seguranca">
          <div className="mx-auto max-w-7xl rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900">
            <h2 id="titulo-seguranca" className="text-xl font-extrabold text-slate-900 dark:text-slate-50">
              Segurança
            </h2>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
              Taxa local no ranking estadual: {observatorioData.rankingHomicidiosGoias.find((item) => item.nome.includes("Águas Lindas"))?.taxa.toLocaleString("pt-BR", { minimumFractionDigits: 1 }) ?? "18,7"}/100 mil.
            </p>
          </div>
        </section>

        <section id="regional" className="scroll-mt-20 px-4 py-10" aria-labelledby="titulo-regional">
          <div className="mx-auto max-w-7xl rounded-2xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900">
            <h2 id="titulo-regional" className="text-xl font-extrabold text-slate-900 dark:text-slate-50">
              Contexto regional
            </h2>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
              Área territorial de {observatorioData.indicadoresMunicipais.areaKm2.toLocaleString("pt-BR")} km², densidade de
              {" "}
              {observatorioData.indicadoresMunicipais.densidadeHabKm2.toLocaleString("pt-BR")} hab/km² e crescimento populacional
              acelerado no eixo da RIDE-DF.
            </p>
          </div>
        </section>

        <PoliticalRadar data={observatorioData} />

        <section id="central" className="scroll-mt-20 px-4 py-10" aria-labelledby="titulo-central">
          <div className="mx-auto max-w-7xl space-y-4">
            <h2 id="titulo-central" className="text-xl font-extrabold text-slate-900 dark:text-slate-50">
              Central de dados
            </h2>
            <section id="evidencias" className="scroll-mt-20" aria-label="Evidências e exportações">
              <DataExportActions rows={exportRows} metadata={exportMetadata} />
            </section>
          </div>
        </section>
      </main>

      <footer className="border-t border-slate-200 bg-white/80 px-4 py-8 text-sm text-slate-600 dark:border-slate-800 dark:bg-slate-950/80 dark:text-slate-400">
        <div className="mx-auto max-w-7xl">
          <p className="font-semibold text-slate-800 dark:text-slate-100">
            Observatório Eleitoral Águas Lindas de Goiás 2026
          </p>
          <p className="mt-1">
            Consolidação técnica com base em IBGE, TRE-GO/TSE, ANTT, SINISA, DATASUS/SES-GO, IMB, IPEDF e Siconfi.
            Projeto em React + TypeScript + Tailwind CSS com foco em transparência de evidências e monitoramento eleitoral.
          </p>
          <button
            type="button"
            onClick={() => scrollToAnchor("dashboard")}
            className="mt-3 rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold text-slate-700 transition hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
          >
            Voltar ao topo
          </button>
        </div>
      </footer>

      <QuickSearchModal isOpen={searchOpen} onClose={() => setSearchOpen(false)} items={quickSearchItems} />
    </div>
  );
}

export default App;
