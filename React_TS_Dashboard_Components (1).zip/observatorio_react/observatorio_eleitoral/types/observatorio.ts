/**
 * Tipos centrais do Observatório Eleitoral Águas Lindas de Goiás 2026.
 * Fonte canônica: Observatorio-V22-Ultra-Mais.html.
 */

/** Representa um valor em reais. */
export type Reais = number;

/** Metadados básicos de fonte e atualização de um indicador. */
export interface FonteDado {
  /** Nome da instituição/base (ex.: IBGE, TRE-GO, SINISA). */
  fonte: string;
  /** Recorte temporal de referência (ex.: 2026, 2024, 15/07/2026). */
  referencia: string;
  /** Observações metodológicas relevantes. */
  observacoes?: string;
}

/** Indicadores demográficos e territoriais do município. */
export interface IndicadoresMunicipais {
  pop2022: number;
  pop2025: number;
  pop2026: number;
  popWorldSecundario?: number;
  tgc2025a2026: number;
  crescimento2010a2025: number;
  areaKm2: number;
  densidadeHabKm2: number;
}

/** Estatísticas de eleitorado e perfil eleitoral. */
export interface EstatisticasEleitorais {
  eleitorado2018: number;
  eleitorado2022: number;
  eleitorado2024: number;
  eleitorado2026TreGo: number;
  eleitorado2026Tse: number;
  totalEleitoradoGoias: number;
  mulheresPct: number;
  homensPct: number;
  nomeSocial: number;
  biometriaGoias: number;
  discrepanciaTreVsTse: number;
  comparecimento2024: number;
  comparecimentoPct?: number;
  abstencao2024: number;
  abstencaoPct?: number;
  jovemPct: number;
  jovemAbs: number;
  adultoPct: number;
  adultoAbs: number;
  idosoPct: number;
  idosoAbs: number;
  indigenasPop: number;
  indigenasEleitores: number;
}

/** Linha de candidato e percentual em pesquisa espontânea. */
export interface CandidatoPesquisa {
  nome: string;
  percentual: number;
}

/** Estrutura de pesquisas eleitorais (estadual e federal). */
export interface PesquisasEleitorais {
  exataEstadual: CandidatoPesquisa[];
  exataFederal: CandidatoPesquisa[];
  igapeNaoSabePct: number;
  indecisaoTotalPct?: number;
  amostraExata?: number;
  amostraIgape?: number;
  margemExataPct?: number;
  margemIgapePct?: number;
}

/** Indicadores de transporte, mobilidade e custo tarifário. */
export interface TransporteMobilidade {
  tarifaBrasilia: Reais;
  tarifaTaguatinga: Reais;
  tarifaCeilandia: Reais;
  tarifaMunicipal?: Reais;
  diasUteisPadrao: number;
  salarioMinimo: Reais;
  passageirosEntornoDia?: number;
}

/** Indicadores de saneamento e saúde ambiental. */
export interface SaneamentoIndicadores {
  esgoto2017Pct: number;
  esgoto2024Pct: number;
  aguaPct: number;
  esgotoTratadoSobreAguaPct: number;
  esgotoTratadoVolPct: number;
  perdasPct?: number;
  hidrometracaoPct?: number;
  residuosPct?: number;
  consumoLitrosHabDia?: number;
  precoM3?: Reais;
  semEsgotoPct: number;
  semEsgotoAbs: number;
  semAguaPct: number;
  semAguaAbs?: number;
  investimentoSaneamento: Reais;
  investimentoPerCapita: Reais;
  obitosAgua: number;
  internacoesAgua: number;
  mediaGoiasPct?: number;
  mediaBrasilPct?: number;
  esgotoTratadoM3?: number;
}

/** Indicadores de saúde assistencial, com foco HEALGO e mortalidade. */
export interface SaudeIndicadores {
  mortalidadeInfantilDe: number;
  mortalidadeInfantilPara: number;
  healgoLeitos: number;
  healgoLeitosProjetado: number;
  healgoAtendimentosAno: number;
  healgoInvestimentoMilhoes: number;
  healgoPopulacaoAlcancada: number;
  healgoAreaConstruidaM2: number;
  healgoUti: number;
  healgoEnfermaria: number;
  healgoUcin: number;
  healgoOutros?: number;
  healgoCeletistas?: number;
  healgoEstatutarios?: number;
}

/** Indicadores de educação e desenvolvimento humano. */
export interface EducacaoIndicadores {
  idebAnosIniciais: number;
  idebAnosFinais: number;
  idebMelhorHistorico?: boolean;
  idhm: number;
  escolarizacaoPct: number;
  escolarizacao2022Pct?: number;
  matriculas: number;
  ensinoMedio: number;
  profissional: number;
  escolas?: number;
  escolasEpt?: number;
}

/** Indicadores econômicos e fiscais. */
export interface EconomiaIndicadores {
  pibBi: number;
  pibPerCapita: number;
  pibRideDfBi: number;
  pibRideDf2022Bi?: number;
  crescimentoRideDfPct?: number;
  receitas2025: Reais;
  despesas2025: Reais;
  empresas: number;
  pequenasPct: number;
  incorporacao?: number;
  admissoes: number;
  desligamentos: number;
  saldoEmpregos: number;
  loa2026: Reais;
  poloIndustrialEmpresas: number;
  poloIndustrialEmpregos: number;
  poloIndustrialInicioObras?: number;
  poloSetores?: string[];
  aeroportoCargas: boolean;
}

/** Linha orçamentária da LOA por órgão/pasta. */
export interface ItemLoaPasta {
  pasta: string;
  valor: Reais;
}

/** Município do Entorno com recorte socioeconômico. */
export interface MunicipioEntorno {
  nome: string;
  eleitorado: number;
  populacao: number;
  densidade?: number;
  pibBi?: number;
}

/** Linha de ranking por taxa de homicídio. */
export interface RankingHomicidio {
  nome: string;
  taxa: number;
}

/** Série temporal simples para indicadores. */
export interface SerieTemporalPonto {
  ano: number;
  valor: number;
  unidade: string;
}

/** Conjunto de séries temporais usadas no painel. */
export interface SeriesTemporais {
  populacao: SerieTemporalPonto[];
  esgoto: SerieTemporalPonto[];
  mortalidadeInfantil: SerieTemporalPonto[];
}

/** Item de monitoramento do radar eleitoral e janela sensível. */
export interface ItemChecklistRadar {
  evento: string;
  dataReferencia: string;
  marcador: string;
  baseLegalOuFonte?: string;
}

/** Bloco de metadados do observatório e governança dos dados. */
export interface MetadadosObservatorio {
  nome: string;
  versao: string;
  secaoTotal: number;
  cidade: string;
  uf: string;
  resumoFontes: string[];
}

/** Verificação das figuras-chave declaradas pelo usuário vs valor observado na base. */
export interface FiguraChaveVerificacao {
  indicador: string;
  valorDeclarado: string;
  valorObservado: string;
  status: "coerente" | "divergente";
  observacao?: string;
}

/** Objeto raiz do observatório com todos os domínios de dados. */
export interface ObservatorioData {
  metadados: MetadadosObservatorio;
  fontes: Record<string, FonteDado>;
  figurasChaveVerificadas: FiguraChaveVerificacao[];
  indicadoresMunicipais: IndicadoresMunicipais;
  estatisticasEleitorais: EstatisticasEleitorais;
  pesquisas: PesquisasEleitorais;
  transporte: TransporteMobilidade;
  saneamento: SaneamentoIndicadores;
  saude: SaudeIndicadores;
  educacao: EducacaoIndicadores;
  economia: EconomiaIndicadores;
  loaPorPasta: ItemLoaPasta[];
  entornoDf: MunicipioEntorno[];
  rankingHomicidiosGoias: RankingHomicidio[];
  seriesTemporais: SeriesTemporais;
  checklistRadar72h: ItemChecklistRadar[];
}
