/**
 * Tipos centrais do Observatório Eleitoral Águas Lindas de Goiás 2026.
 * Fonte canônica: Observatorio-V22-Ultra-Mais.html.
 */
export {};
